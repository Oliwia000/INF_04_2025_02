﻿using System;
namespace konsola
{
    public class Program
    {
        public static string[,] jednostki = new string[,]
       {
        { "m", "km", "mi" },
        { "mg", "kg", "lb" },
        { "C", "F", "K" }
       };
        public static void Main()
        {
            Console.WriteLine(" Wybierz typ konwersji : ");
            Console.WriteLine(" 1. Długość (m, km, mi) ");
            Console.WriteLine(" 2. Masa (mg, kg, lb) ");
            Console.WriteLine(" 3. Temperatura (C, F, K) ");

            if (!int.TryParse(Console.ReadLine(), out int typ) || typ < 1 || typ > 3)
            {
                Console.WriteLine("Błąd: Nie poprawna opcja.");
                return;
            }

            Console.Write(" Podaj wartość do konwersji: \n ");
            if (!double.TryParse(Console.ReadLine(), out double wartosc))
            {
                Console.WriteLine("Błąd: wpisz liczbę.");
                return;
            }

            Console.Write(" Podaj jednostkę źródłową ( m , km, mi):  ");
            string z = Console.ReadLine();

            Console.Write(" Podaj jednostkę źródłową ( m , km, mi):  ");
            string na = Console.ReadLine();

            double wynik = Konwertuj(typ, z, na, wartosc);
            if (wynik == -1)
                Console.WriteLine("Błąd: niepoprawne jednostki.");
            else
                Console.WriteLine($" Wynik: {wynik} ");
        }

        public static double Konwertuj(int typ, string z, string na, double wartosc)
        {
            if (typ == 1) return Dlugosc(z, na, wartosc);
            if (typ == 2) return Masa(z, na, wartosc);
            if (typ == 3) return Temperatura(z, na, wartosc);
            return -1;
        }

        public static double Dlugosc(string z, string na, double w)
        {
            double m;
            if (z == "m") m = w;
            else if (z == "km") m = w * 1000;
            else if (z == "mi") m = w * 1609.34;
            else return -1;

            if (na == "m") return m;
            if (na == "km") return m / 1000;
            if (na == "mi") return m / 1609.34;
            return -1;
        }
        public static double Masa(string z, string na, double w)
        {
            double mg;
            if (z == "mg") mg = w;
            else if (z == "kg") mg = w * 1000000;
            else if (z == "lb") mg = w * 453592;
            else return -1;

            if (na == "mg") return mg;
            if (na == "kg") return mg / 1000000;
            if (na == "lb") return mg / 453592;
            return -1;
        }
        public static double Temperatura(string z, string na, double w)
        {
            double c;
            if (z == "C") c = w;
            else if (z == "F") c = (w - 32) * 5 / 9;
            else if (z == "K") c = w - 273.15;
            else return -1;

            if (na == "C") return c;
            if (na == "F") return c * 9 / 5 + 32;
            if (na == "K") return c + 273.15;
            return -1;
        }
    }
}