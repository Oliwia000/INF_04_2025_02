
<img width="1344" height="792" alt="konsola1" src="https://github.com/user-attachments/assets/6f157ad1-5f7a-425c-8f4c-1a00a4ff9df5" />


<img width="1119" height="633" alt="test1" src="https://github.com/user-attachments/assets/31f32342-10a7-4cb6-a6d6-fd676e44f754" />
